package com.capgemini.truckbooking.Exception;

public class TSException extends Exception {

	public TSException(String message) {
		super(message);
	}
}